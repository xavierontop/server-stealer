### SERVER STEALER  VERISON:
this just copy the server channles

### Current Worked Benchmarks:
- Working: `1000%`
- NotWorking: `26%`


| SS OF THE TOOL| 
| ------------- | 
| ![image](https://cdn.discordapp.com/attachments/846196496864510003/846519295822266398/unknown.png) |
| ![image](https://cdn.discordapp.com/attachments/846196496864510003/846519343054716968/unknown.png) |
